package br.com.lablims.dao;

import br.com.lablims.model.Xteste;

/**
 *
 * @author rafael
 */
public class XtesteDAO extends GenenicoDAO<Xteste> {



}
