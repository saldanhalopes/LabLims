package br.com.lablims.dao;

import br.com.lablims.audit.Audit;
import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.CaixaRfMateriaPrima;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.swing.JOptionPane;

/**
 *
 * @author rafael
 */
public class CaixaRfMateriaPrimaDAO extends GenenicoDAO<CaixaRfMateriaPrima> {

    public CaixaRfMateriaPrima findUltimaCaixa(String tipo, String ano) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<CaixaRfMateriaPrima> root = cq.from(CaixaRfMateriaPrima.class);
            cq.where(cb.and(
                    cb.like(root.get("caixa"), tipo + "%"),
                    cb.like(root.get("caixa"), "%" + ano)
            ));
            cq.orderBy(cb.desc(root.get("caixa")));
            cq.select(root);
            TypedQuery<CaixaRfMateriaPrima> q = em.createQuery(cq);
            q.setMaxResults(1);
            return q.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<CaixaRfMateriaPrima> findAllByTipo(Map<String, String> conditional) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<CaixaRfMateriaPrima> root = cq.from(CaixaRfMateriaPrima.class);
            if (conditional != null) {
                for (String key : conditional.keySet()) {
                    if (!"Todos".equals(conditional.get(key))) {
                        cq.where(cb.like(root.get(key), conditional.get(key) + "%"));
                    }
                }
            }
            cq.orderBy(cb.desc(root.get("id")));
            cq.select(root);
            Query q = em.createQuery(cq);
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

    public List<CaixaRfMateriaPrima> findCaixasAbertasByTipo(String tipo, String ano) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<CaixaRfMateriaPrima> root = cq.from(CaixaRfMateriaPrima.class);
            cq.where(cb.and(
                    cb.like(root.get("caixa"), tipo + "%"),
                    cb.like(root.get("caixa"), "%" + ano),
                    cb.isNull(root.get("dataFechamento"))
            ));
            cq.orderBy(cb.desc(root.get("caixa")));
            cq.select(root);
            TypedQuery<CaixaRfMateriaPrima> q = em.createQuery(cq);
            return q.getResultList();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }
    
    public List<CaixaRfMateriaPrima> findCaixasByTipo(String tipo, String ano) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<CaixaRfMateriaPrima> root = cq.from(CaixaRfMateriaPrima.class);
            cq.where(cb.and(
                    cb.like(root.get("caixa"), tipo + "%"),
                    cb.like(root.get("caixa"), "%" + ano)
            ));
            cq.orderBy(cb.desc(root.get("caixa")));
            cq.select(root);
            TypedQuery<CaixaRfMateriaPrima> q = em.createQuery(cq);
            return q.getResultList();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<CaixaRfMateriaPrima> readAuditoria(Integer maxResults) {
        Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<CaixaRfMateriaPrima> caixas = new ArrayList<>();
        try {
            stmt = conn.prepareStatement("SELECT tba_caixa_rf_materia_prima_auditoria.*, "
                    + "tbc_revinfo_auditoria.computador, "
                    + "tbc_revinfo_auditoria.ultima_modificacao, "
                    + "tbc_revinfo_auditoria.user_computador, "
                    + "tbc_revinfo_auditoria.modificado_por, "
                    + "tbc_revinfo_auditoria.motivo "
                    + "FROM tba_caixa_rf_materia_prima_auditoria  "
                    + "INNER JOIN tbc_revinfo_auditoria "
                    + "ON tba_caixa_rf_materia_prima_auditoria.REV = tbc_revinfo_auditoria.id "
                    + "ORDER BY tba_caixa_rf_materia_prima_auditoria.REV DESC "
                    + "limit ?");
            stmt.setInt(1, maxResults);
            rs = stmt.executeQuery();
            while (rs.next()) {
                CaixaRfMateriaPrima caixaRf = new CaixaRfMateriaPrima();
                Audit audit = new Audit();
                caixaRf.setId(rs.getLong("id"));
                caixaRf.setCaixa(rs.getString("caixa"));
                caixaRf.setDataAbertura(rs.getDate("data_abertura"));
                caixaRf.setCentroCusto(rs.getString("centro_custo"));
                caixaRf.setDeposito(rs.getString("deposito"));
                caixaRf.setDataFechamento(rs.getDate("data_fechamento"));
                caixaRf.setCaixa_MOD(rs.getBoolean("caixa_MOD"));
                caixaRf.setDataAbertura_MOD(rs.getBoolean("dataAbertura_MOD"));
                caixaRf.setDataFechamento_MOD(rs.getBoolean("dataFechamento_MOD"));
                caixaRf.setCentroCusto_MOD(rs.getBoolean("centroCusto_MOD"));
                caixaRf.setDeposito_MOD(rs.getBoolean("deposito_MOD"));
                caixaRf.setVersion(rs.getInt("version"));
                audit.setMOD(rs.getInt("REVTYPE"));
                audit.setComputador(rs.getString("computador"));
                audit.setUserComputador(rs.getString("user_computador"));
                audit.setUltimaModificacao(rs.getTimestamp("ultima_modificacao"));
                audit.setUltimaModificacaoPor(rs.getString("modificado_por"));
                audit.setMotivo(rs.getString("motivo"));
                caixaRf.setAudit(audit);
                caixas.add(caixaRf);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro: " + ex);
        } finally {
            ConnectionFactory.closeConection(conn, stmt, rs);
        }
        return caixas;
    }

}
