/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import br.com.lablims.interfaces.EntidadeBase;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import br.com.lablims.audit.Audit;
import br.com.lablims.audit.AuditListener;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author rafael
 */
@Entity
@Table(name = "tb_caixa_rf_materia_prima")
@NamedQueries({
    @NamedQuery(name = "CaixaRfMateriaPrima.findAll", query = "SELECT crf FROM CaixaRfMateriaPrima crf")})
@DynamicInsert(true)
@DynamicUpdate(true)
@Audited(withModifiedFlag = true)
@AuditTable(value = "tba_caixa_rf_materia_prima_auditoria")
@EntityListeners(AuditListener.class)
public class CaixaRfMateriaPrima implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "caixa")
    private String caixa;

    @Column(name = "data_abertura")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAbertura;
    
    @Column(name = "data_fechamento")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataFechamento;
    
     @Column(name = "centro_custo")
    private String centroCusto;

    @Column(name = "deposito")
    private String deposito;

    @Column(name = "version")
    private Integer version;

    @Transient
    private Audit audit = new Audit();

    @Transient
    private Boolean Caixa_MOD;

    @Transient
    private Boolean DataAbertura_MOD;
    
    @Transient
    private Boolean DataFechamento_MOD;
    
    @Transient
    private Boolean CentroCusto_MOD;

    @Transient
    private Boolean Deposito_MOD;
    
    public CaixaRfMateriaPrima() {
    }

    public CaixaRfMateriaPrima(Long id) {
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCaixa() {
        return caixa;
    }

    public void setCaixa(String caixa) {
        this.caixa = caixa;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(Date dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public Date getDataFechamento() {
        return dataFechamento;
    }

    public void setDataFechamento(Date dataFechamento) {
        this.dataFechamento = dataFechamento;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    public Boolean getCaixa_MOD() {
        return Caixa_MOD;
    }

    public void setCaixa_MOD(Boolean Caixa_MOD) {
        this.Caixa_MOD = Caixa_MOD;
    }

    public Boolean getDataAbertura_MOD() {
        return DataAbertura_MOD;
    }

    public void setDataAbertura_MOD(Boolean DataAbertura_MOD) {
        this.DataAbertura_MOD = DataAbertura_MOD;
    }

    public Boolean getDataFechamento_MOD() {
        return DataFechamento_MOD;
    }

    public void setDataFechamento_MOD(Boolean DataFechamento_MOD) {
        this.DataFechamento_MOD = DataFechamento_MOD;
    }

    public String getCentroCusto() {
        return centroCusto;
    }

    public void setCentroCusto(String centroCusto) {
        this.centroCusto = centroCusto;
    }

    public String getDeposito() {
        return deposito;
    }

    public void setDeposito(String deposito) {
        this.deposito = deposito;
    }

    public Boolean getCentroCusto_MOD() {
        return CentroCusto_MOD;
    }

    public void setCentroCusto_MOD(Boolean CentroCusto_MOD) {
        this.CentroCusto_MOD = CentroCusto_MOD;
    }

    public Boolean getDeposito_MOD() {
        return Deposito_MOD;
    }

    public void setDeposito_MOD(Boolean Deposito_MOD) {
        this.Deposito_MOD = Deposito_MOD;
    }
    
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CaixaRfMateriaPrima other = (CaixaRfMateriaPrima) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return "CaixaRfMateriaPrima{" + "id=" + id + ", caixa=" + caixa + ", dataAbertura=" + dataAbertura + ", dataFechamento=" + dataFechamento + ", centroCusto=" + centroCusto + ", deposito=" + deposito + ", version=" + version + ", audit=" + audit + ", Caixa_MOD=" + Caixa_MOD + ", DataAbertura_MOD=" + DataAbertura_MOD + ", DataFechamento_MOD=" + DataFechamento_MOD + ", CentroCusto_MOD=" + CentroCusto_MOD + ", Deposito_MOD=" + Deposito_MOD + '}';
    }


}
