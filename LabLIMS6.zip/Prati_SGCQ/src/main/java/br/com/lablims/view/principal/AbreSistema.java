/*
 * Copyright (C) 2019 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.view.principal;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * O <code>AbreSistema</code> implementa o carregaemnto inicial do sistema
 *
 * @author rafae.lopes
 * @version 1.00
 */
public class AbreSistema {

    /**
     * Método para carrer o Form Splash via <code>Thread</code>.
     */
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                // Define o tipo de Layout do Sistema ("Metal", "Nimbus", "Windows").
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Splash.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Splash splash = new Splash();
                splash.setVisible(true);
                new Thread() {
                    @Override
                    public void run() {
                        //if (sys.systemUpdate()) {
//                            final String exe = "java -jar M:\\controledequalidade_compartilhada\\CQ_Desktop\\CQ_Update.jar";
//                            //executar atraves proprio sistema.. e lembrar de colocar no arquivo xml config o caminho da atualização
//                            try {
//                                Runtime.getRuntime().exec(exe);
//                            } catch (IOException ex) {
//                                Logger.getLogger(FrmLogin.class.getName()).log(Level.SEVERE, null, ex);
//                            }
//
//                            System.exit(0);
                        //} else {
                        
//                        if (sys.systemLog_Off()) {
//                            int logResult = JOptionPane.showConfirmDialog(null,
//                                    "Sistema em Manutenção!\nDeseja continuar?", "Alerta",
//                                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE,
//                                    new ImageIcon(getClass().getResource("/img/icon_manutencao.png")));
//                            if (logResult == 0) {
//                                loginDAO.updateUserLogin(System.getProperty("user_id"));
//                                loginDAO.updateFalhaAcesso(user, false);
//                                loginDAO.createLogLoginLogout("Login", user.getUser());
//                                new FrmPrincipal().setVisible(true);
//                                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
//                                dispose();
//                            } else {
//                                System.exit(0);
//                            }
//                        }
                        
                        
                        FrmLogin dashboard = new FrmLogin(splash);
                        dashboard.setVisible(true);
                        //}
                    }
                }.start();
            }
        });

    }
}
