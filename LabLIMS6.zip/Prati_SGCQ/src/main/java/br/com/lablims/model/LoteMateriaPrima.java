/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import br.com.lablims.audit.Audit;
import br.com.lablims.audit.AuditListener;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import br.com.lablims.interfaces.EntidadeBase;
import javax.persistence.CascadeType;
import javax.persistence.EntityListeners;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

/**
 * <code>LoteMateriaPrima</code> classe LoteMateriaPrima
 *
 * @author rafae.lopes
 * @version 1.00
 */
@Entity
@Table(name = "tb_lote_materia_prima")
@NamedQueries({
    @NamedQuery(name = "LoteMateriaPrima.findLote", query = "Select lot FROM LoteMateriaPrima lot WHERE lot.lote = :lote")})
@DynamicInsert(true)
@DynamicUpdate(true)
@Audited(withModifiedFlag = true)
@AuditTable(value = "tba_lote_materia_prima_auditoria")
@EntityListeners(AuditListener.class)
public class LoteMateriaPrima implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lote", unique = true, length = 50)
    private String lote;

    @ManyToOne()
    @JoinColumn(name = "material_id", referencedColumnName = "id")
    private Material material;
    
    @NotAudited
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "lote")
    private LoteMateriaPrimaInfo loteInfo;
    
    @Column(name = "version")
    private Integer version;
        
    @Transient
    private Audit audit = new Audit();

    @Transient
    private Boolean Lote_MOD;

    @Transient
    private Boolean Material_MOD;

    @Transient
    private Boolean LoteInfo_MOD;
    
    public LoteMateriaPrima() {
    }

    public LoteMateriaPrima(Long id) {
        this.id = id;
    }

    public LoteMateriaPrima(String lote, LoteMateriaPrimaInfo loteInfo) {
        this.lote = lote;
        this.loteInfo = loteInfo;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public LoteMateriaPrimaInfo getLoteInfo() {
        return loteInfo;
    }

    public void setLoteInfo(LoteMateriaPrimaInfo loteInfo) {
        this.loteInfo = loteInfo;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    public Boolean getLote_MOD() {
        return Lote_MOD;
    }

    public void setLote_MOD(Boolean Lote_MOD) {
        this.Lote_MOD = Lote_MOD;
    }

    public Boolean getMaterial_MOD() {
        return Material_MOD;
    }

    public void setMaterial_MOD(Boolean Material_MOD) {
        this.Material_MOD = Material_MOD;
    }

    public Boolean getLoteInfo_MOD() {
        return LoteInfo_MOD;
    }

    public void setLoteInfo_MOD(Boolean LoteInfo_MOD) {
        this.LoteInfo_MOD = LoteInfo_MOD;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 19 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoteMateriaPrima other = (LoteMateriaPrima) obj;
        return Objects.equals(this.id, other.id);
    }

}
