/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import br.com.lablims.audit.Audit;
import br.com.lablims.audit.AuditListener;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import br.com.lablims.interfaces.EntidadeBase;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityListeners;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

/**
 *
 * @author rafael.lopes
 */
@Entity
@Table(name = "tb_material")
@NamedQueries({
    @NamedQuery(name = "Material.findAll", query = "SELECT m FROM Material m"),
    @NamedQuery(name = "Material.findById", query = "SELECT m FROM Material m WHERE m.id = :id"),
    @NamedQuery(name = "Material.findCodMaterial", query = "Select m FROM Material m WHERE m.codMaterial = :codMaterial"),
    @NamedQuery(name = "Material.findMaterialMetodologiaById", query = "Select m FROM Material m JOIN FETCH m.metodologia mtd WHERE m.id = :id"),
    @NamedQuery(name = "Material.findMaterialByMetodologia", query = "Select m FROM Material m JOIN FETCH m.metodologia mtd WHERE mtd.id = :id")})
@DynamicInsert(true)
@DynamicUpdate(true)
@Audited(withModifiedFlag = true)
@AuditTable(value = "tba_material_auditoria")
@EntityListeners(AuditListener.class)
public class Material implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cod_material", nullable = false, unique = true)
    private Integer codMaterial;

    @Column(name = "material", nullable = false, length = 250)
    private String material;

    @Column(name = "tipo", nullable = false, length = 10)
    private String tipo;

    @NotAudited
    @ManyToMany(mappedBy = "material")
    private Set<Metodologia> metodologia = new HashSet<>();

    @Column(name = "version")
    private Integer version;

    @Transient
    private Audit audit = new Audit();

    @Transient
    private Boolean MOD;

    @Transient
    private Boolean CodMaterial_MOD;

    @Transient
    private Boolean Material_MOD;

    @Transient
    private Boolean Tipo_MOD;

    public Material() {
    }

    public Material(Long id) {
        this.id = id;
    }

    public Material(Integer codMaterial, String material, String tipo) {
        this.codMaterial = codMaterial;
        this.material = material;
        this.tipo = tipo;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getCodMaterial() {
        return codMaterial;
    }

    public void setCodMaterial(Integer codMaterial) {
        this.codMaterial = codMaterial;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Set<Metodologia> getMetodologia() {
        return metodologia;
    }

    public void setMetodologia(Set<Metodologia> metodologia) {
        this.metodologia = metodologia;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    public Boolean getMOD() {
        return MOD;
    }

    public void setMOD(Boolean MOD) {
        this.MOD = MOD;
    }

    public Boolean getCodMaterial_MOD() {
        return CodMaterial_MOD;
    }

    public void setCodMaterial_MOD(Boolean CodMaterial_MOD) {
        this.CodMaterial_MOD = CodMaterial_MOD;
    }

    public Boolean getMaterial_MOD() {
        return Material_MOD;
    }

    public void setMaterial_MOD(Boolean Material_MOD) {
        this.Material_MOD = Material_MOD;
    }

    public Boolean getTipo_MOD() {
        return Tipo_MOD;
    }

    public void setTipo_MOD(Boolean Tipo_MOD) {
        this.Tipo_MOD = Tipo_MOD;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Material other = (Material) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return "Material{" + "id=" + id + ", codMaterial=" + codMaterial + ", material=" + material + ", tipo=" + tipo + '}';
    }

    public void addMetodologia(Metodologia mtd) {
        this.metodologia.add(mtd);
        mtd.getMaterial().add(this);
    }
 
    public void removeMetodologia(Metodologia mtd) {
        this.metodologia.remove(mtd);
        mtd.getMaterial().remove(this);
    }
    
}
