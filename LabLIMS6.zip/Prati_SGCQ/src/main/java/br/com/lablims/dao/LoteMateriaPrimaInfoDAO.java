package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteMateriaPrima;
import br.com.lablims.model.LoteMateriaPrimaInfo;
import javax.persistence.EntityManager;
import javax.persistence.TransactionRequiredException;

/**
 *
 * @author rafael
 */
public class LoteMateriaPrimaInfoDAO extends GenenicoDAO<LoteMateriaPrimaInfo> {

    public void salvarLoteMateriaPrimaInfo(LoteMateriaPrimaInfo loteInfo, LoteMateriaPrima lote) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            em.getTransaction().begin();
            lote = em.find(LoteMateriaPrima.class, lote.getId());
            loteInfo.setLote(lote);
            em.persist(loteInfo);
            em.getTransaction().commit();
        } catch (Exception ex) {
            em.getTransaction().rollback();
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

    public void atualizarLoteMateriaPrimaInfo(LoteMateriaPrimaInfo loteInfo) throws TransactionRequiredException {
        EntityManager em = ConnectionFactory.em();
        try {
            em.getTransaction().begin();
            if (em.find(LoteMateriaPrimaInfo.class, loteInfo.getId()) == null) {
                throw new TransactionRequiredException("Erro ao Atualizar!");
            }
            String update = "UPDATE LoteMateriaPrimaInfo lm SET "
                    + "lm.obsCq = :obsCq, "
                    + "lm.prevLiberacao = :prevLiberacao, "
                    + "lm.qtdEstoque = :qtdEstoque, "
                    + "lm.status = :status, "
                    + "lm.tempoEstimadoLiberacao = :tempoEstimadoLiberacao, "
                    + "lm.version = :version "
                    + "WHERE u.id = :id";
            em.createQuery(update)
                    .setParameter("obsCq", loteInfo.getObsCq())
                    .setParameter("prevLiberacao", loteInfo.getPrevLiberacao())
                    .setParameter("qtdEstoque", loteInfo.getQtdEstoque())
                    .setParameter("status", loteInfo.getStatus())
                    .setParameter("tempoEstimadoLiberacao", loteInfo.getTempoEstimadoLiberacao())
                    .setParameter("id", loteInfo.getId())
                    .executeUpdate();
            em.getTransaction().commit();
        } catch (TransactionRequiredException ex) {
            em.getTransaction().rollback();
            throw new TransactionRequiredException("Erro ao Atualizar!");
        } finally {
            em.close();
        }
    }

}
