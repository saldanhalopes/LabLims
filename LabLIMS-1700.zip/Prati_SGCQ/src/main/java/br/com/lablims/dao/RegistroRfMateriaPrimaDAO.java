package br.com.lablims.dao;

import br.com.lablims.audit.Audit;
import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.CaixaRfMateriaPrima;
import br.com.lablims.model.Material;
import br.com.lablims.model.RegistroRfMateriaPrima;
import br.com.lablims.model.UnidadeMedida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import javax.swing.JOptionPane;

/**
 *
 * @author rafael
 */
public class RegistroRfMateriaPrimaDAO extends GenenicoDAO<RegistroRfMateriaPrima> {

    public Boolean checkRegistroIsExits(String lote) {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("RegistroRfMateriaPrima.findByLote", RegistroRfMateriaPrima.class)
                    .setParameter("lote", lote)
                    .getSingleResult().getId() != null;
        } catch (NoResultException ex) {
            return false;
        } finally {
            em.close();
        }
    }

    public List<RegistroRfMateriaPrima> findAllRegistrosRf(Integer maxResults) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<RegistroRfMateriaPrima> root = cq.from(RegistroRfMateriaPrima.class);
            Join<RegistroRfMateriaPrima, CaixaRfMateriaPrima> joinCaixa = root.join("caixa", JoinType.INNER);
            Join<RegistroRfMateriaPrima, Material> joinMaterial = root.join("material", JoinType.INNER);
            Join<RegistroRfMateriaPrima, UnidadeMedida> joinUnidade = root.join("unidade", JoinType.INNER);
            cq.orderBy(cb.desc(root.get("caixa")));
            cq.select(root);
            Query q = em.createQuery(cq);
            if (maxResults != null) {
                q.setMaxResults(maxResults);
            }
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

    public List<RegistroRfMateriaPrima> readAuditoria(Integer maxResults) {
        Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<RegistroRfMateriaPrima> regRfs = new ArrayList<>();
        try {
            stmt = conn.prepareStatement("SELECT tba_registro_rf_materia_prima_auditoria.*, "
                    + "tbc_revinfo_auditoria.computador, "
                    + "tbc_revinfo_auditoria.ultima_modificacao, "
                    + "tbc_revinfo_auditoria.user_computador, "
                    + "tbc_revinfo_auditoria.modificado_por, "
                    + "tbc_revinfo_auditoria.motivo "
                    + "FROM tba_registro_rf_materia_prima_auditoria  "
                    + "INNER JOIN tbc_revinfo_auditoria "
                    + "ON tba_registro_rf_materia_prima_auditoria.REV = tbc_revinfo_auditoria.id "
                    + "ORDER BY tba_registro_rf_materia_prima_auditoria.REV DESC "
                    + "limit ?");
            stmt.setInt(1, maxResults);
            rs = stmt.executeQuery();
            while (rs.next()) {
                RegistroRfMateriaPrima regRf = new RegistroRfMateriaPrima();
                CaixaRfMateriaPrima caixaRf = new CaixaRfMateriaPrima();
                Material material = new Material();
                UnidadeMedida unidade = new UnidadeMedida();
                Audit audit = new Audit();
                regRf.setId(rs.getLong("id"));
                caixaRf.setId(rs.getLong("caixa_id"));
                regRf.setCaixa(caixaRf);
                material.setId(rs.getLong("material_id"));
                regRf.setMaterial(material);
                unidade.setId(rs.getLong("unidade_id"));
                regRf.setUnidade(unidade);
                regRf.setLote(rs.getString("lote"));
                regRf.setQuantidade(rs.getFloat("quantidade"));
                regRf.setObs(rs.getString("obs"));
                regRf.setCaixa_MOD(rs.getBoolean("caixa_MOD"));
                regRf.setMaterial_MOD(rs.getBoolean("material_MOD"));
                regRf.setUnidade_MOD(rs.getBoolean("unidade_MOD"));
                regRf.setLote_MOD(rs.getBoolean("lote_MOD"));
                regRf.setQuantidade_MOD(rs.getBoolean("quantidade_MOD"));
                regRf.setObs_MOD(rs.getBoolean("obs_MOD"));
                regRf.setVersion(rs.getInt("version"));
                audit.setMOD(rs.getInt("REVTYPE"));
                audit.setComputador(rs.getString("computador"));
                audit.setUserComputador(rs.getString("user_computador"));
                audit.setUltimaModificacao(rs.getTimestamp("ultima_modificacao"));
                audit.setUltimaModificacaoPor(rs.getString("modificado_por"));
                audit.setMotivo(rs.getString("motivo"));
                regRf.setAudit(audit);
                regRfs.add(regRf);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro: " + ex);
        } finally {
            ConnectionFactory.closeConection(conn, stmt, rs);
        }
        return regRfs;
    }

}
