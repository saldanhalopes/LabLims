/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import br.com.lablims.audit.Audit;
import br.com.lablims.audit.AuditListener;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import br.com.lablims.interfaces.EntidadeBase;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

/**
 *
 * @author rafael.lopes
 */
@Entity
@Table(name = "tb_registro_rf_materia_prima")
@NamedQueries({
    @NamedQuery(name = "RegistroRfMateriaPrima.findAll", query = "SELECT rf FROM RegistroRfMateriaPrima rf"),
    @NamedQuery(name = "RegistroRfMateriaPrima.findByLote", query = "SELECT rf FROM RegistroRfMateriaPrima rf WHERE rf.lote = :lote")})
@DynamicInsert(true)
@DynamicUpdate(true)
@Audited(withModifiedFlag = true)
@AuditTable(value = "tba_registro_rf_materia_prima_auditoria")
@EntityListeners(AuditListener.class)
public class RegistroRfMateriaPrima implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "quantidade")
    private Float quantidade;

    @Column(name = "lote")
    private String lote;

    @ManyToOne()
    @JoinColumn(name = "material_id", referencedColumnName = "id")
    private Material material;

    @ManyToOne()
    @JoinColumn(name = "unidade_id", referencedColumnName = "id")
    private UnidadeMedida unidade;

    @ManyToOne()
    @JoinColumn(name = "caixa_id", referencedColumnName = "id")
    private CaixaRfMateriaPrima caixa;

    @Column(name = "obs")
    private String obs;

    @Column(name = "version")
    private Integer version;

    @Transient
    private Audit audit = new Audit();

    @Transient
    private Boolean Quantidade_MOD;

    @Transient
    private Boolean Lote_MOD;

    @Transient
    private Boolean Material_MOD;

    @Transient
    private Boolean Unidade_MOD;

    @Transient
    private Boolean Caixa_MOD;

    @Transient
    private Boolean Obs_MOD;

    public RegistroRfMateriaPrima() {
    }

    public RegistroRfMateriaPrima(Long id) {
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Float getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Float quantidade) {
        this.quantidade = quantidade;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public UnidadeMedida getUnidade() {
        return unidade;
    }

    public void setUnidade(UnidadeMedida unidade) {
        this.unidade = unidade;
    }

    public CaixaRfMateriaPrima getCaixa() {
        return caixa;
    }

    public void setCaixa(CaixaRfMateriaPrima caixa) {
        this.caixa = caixa;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    public Boolean getQuantidade_MOD() {
        return Quantidade_MOD;
    }

    public void setQuantidade_MOD(Boolean Quantidade_MOD) {
        this.Quantidade_MOD = Quantidade_MOD;
    }

    public Boolean getLote_MOD() {
        return Lote_MOD;
    }

    public void setLote_MOD(Boolean Lote_MOD) {
        this.Lote_MOD = Lote_MOD;
    }

    public Boolean getMaterial_MOD() {
        return Material_MOD;
    }

    public void setMaterial_MOD(Boolean Material_MOD) {
        this.Material_MOD = Material_MOD;
    }

    public Boolean getUnidade_MOD() {
        return Unidade_MOD;
    }

    public void setUnidade_MOD(Boolean Unidade_MOD) {
        this.Unidade_MOD = Unidade_MOD;
    }

    public Boolean getCaixa_MOD() {
        return Caixa_MOD;
    }

    public void setCaixa_MOD(Boolean Caixa_MOD) {
        this.Caixa_MOD = Caixa_MOD;
    }

    public Boolean getObs_MOD() {
        return Obs_MOD;
    }

    public void setObs_MOD(Boolean Obs_MOD) {
        this.Obs_MOD = Obs_MOD;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RegistroRfMateriaPrima other = (RegistroRfMateriaPrima) obj;
        return Objects.equals(this.id, other.id);
    }

}
