package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteMateriaPrima;
import br.com.lablims.model.LoteMateriaPrimaInfo;
import br.com.lablims.model.Metodologia;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

/**
 *
 * @author rafael
 */
public class LoteMateriaPrimaDAO extends GenenicoDAO<LoteMateriaPrima> {

    public Boolean checkLoteMateriaPrimaIsExits(String lote) throws EntityNotFoundException, NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLote", LoteMateriaPrima.class)
                    .setParameter("lote", lote)
                    .getSingleResult().getLote() != null;
        } catch (NoResultException ex) {
            return false;
        } finally {
            em.close();
        }
    }

    public LoteMateriaPrima findLoteMateriaPrimaByLote(String lote) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLote", LoteMateriaPrima.class)
                    .setParameter("lote", lote)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public LoteMateriaPrima findLoteMateriaPrimaPlanoAnalise(Long lote_id) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLoteMateriaPrimaPlanoAnalise", LoteMateriaPrima.class)
                    .setParameter("id", lote_id)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<LoteMateriaPrima> findListLoteMateriaPrima(Integer maxResults, 
            Map<String, String> conditional) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            if (conditional != null) {
                for (String key : conditional.keySet()) {
                    cq.where(cb.equal(joinInfo.get(key), conditional.get(key)));
                }
            }
            cq.orderBy(cb.desc(root.get("id")));
            cq.select(root);
            Query q = em.createQuery(cq);
            if (maxResults != null) {
                q.setMaxResults(maxResults);
            }
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

    public List<LoteMateriaPrima> findLoteStatus(Integer maxResults) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            cq.where(cb.notEqual(joinInfo.get("status"), "Liberado"));
            cq.orderBy(cb.desc(root.get("id")));
            cq.select(root);
            Query q = em.createQuery(cq);
            if (maxResults != null) {
                q.setMaxResults(maxResults);
            }
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }
    
    public List<LoteMateriaPrima> findLoteStatus(Integer maxResults, Long id) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            cq.where(cb.and(
                    cb.notEqual(joinInfo.get("status"), "Liberado"),
                    cb.equal(root.get("metodologia").get("id"), id)
            ));
            cq.orderBy(cb.desc(root.get("id")));
            cq.select(root);
            Query q = em.createQuery(cq);
            if (maxResults != null) {
                q.setMaxResults(maxResults);
            }
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }
    
    

}
