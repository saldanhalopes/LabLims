package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteMateriaPrima;
import br.com.lablims.model.LoteMateriaPrimaInfo;
import br.com.lablims.model.LoteMateriaPrimaStatus;
import br.com.lablims.model.PlanoAnalise;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

/**
 *
 * @author rafael
 */
public class LoteMateriaPrimaStatusDAO extends GenenicoDAO<LoteMateriaPrimaStatus> {

    public LoteMateriaPrimaStatus findStatusByPlanoAnalise(Long lote_id, Long pa_id) throws EntityNotFoundException, NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrimaStatus.findStatusByPlanoAnalise", LoteMateriaPrimaStatus.class)
                    .setParameter("lote_id", lote_id)
                    .setParameter("pa_id", pa_id)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<LoteMateriaPrimaStatus> findLotesByStatus(Long lote_id) throws EntityNotFoundException, NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrimaStatus.findStatus", LoteMateriaPrimaStatus.class)
                    .setParameter("lote_id", lote_id)
                    .getResultList();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public String findOnlyStatus(Long lote_id) throws Exception {
        EntityManager em = ConnectionFactory.em();
        StringBuilder sb = new StringBuilder();
        try {
            Query myQuery = em.createNamedQuery("LoteMateriaPrimaStatus.findStatus", LoteMateriaPrimaStatus.class)
                    .setParameter("lote_id", lote_id);
            for (LoteMateriaPrimaStatus loteStatus : (ArrayList<LoteMateriaPrimaStatus>) myQuery.getResultList()) {
                sb.append("  [ ");
                sb.append(loteStatus.getPlanoAnalise().getAnalise().getAnalise());
                sb.append(" - ");
                sb.append(loteStatus.getPlanoAnalise().getAnaliseTipo().getAnaliseTipo());
                sb.append(" - ");
                sb.append(loteStatus.getAnaliseStatus().getAnaliseStatus());
                sb.append(" ]  ");
            }
        } catch (Exception ex) {
            sb = null;
            throw new Exception(ex);
        } finally {
            em.close();
        }
        return sb.toString();
    }

//    public List<LoteMateriaPrimaStatus> findLoteStatusByLaboratorio(Integer maxResults, String lab) throws Exception {
//        EntityManager em = ConnectionFactory.em();
//        try {
//            CriteriaBuilder cb = em.getCriteriaBuilder();
//            CriteriaQuery cq = cb.createQuery();
//            Root<LoteMateriaPrimaStatus> root = cq.from(LoteMateriaPrimaStatus.class);
//            Join<LoteMateriaPrimaStatus, PlanoAnalise> joinPA = root.join("planoAnalise", JoinType.INNER);
//            Join<PlanoAnalise, Setor> joinSetor = joinPA.join("setor", JoinType.INNER);
//            //Join<PlanoAnalise, Metodologia> joinMtd = joinPA.join("metodologia", JoinType.INNER);
//            cq.where(cb.equal(joinSetor.get("siglaSetor"), lab));
//            cq.orderBy(cb.desc(root.get("id")));
//            cq.select(root);
//            Query q = em.createQuery(cq);
//            if (maxResults != null) {
//                q.setMaxResults(maxResults);
//            }
//            return q.getResultList();
//        } catch (Exception ex) {
//            throw new Exception(ex);
//        } finally {
//            em.close();
//        }
//    }

    public List<Object[]> findLoteStatusByMetodologia(Long status, Long lab) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<LoteMateriaPrimaStatus> root = cq.from(LoteMateriaPrimaStatus.class);
            Join<LoteMateriaPrimaStatus, LoteMateriaPrima> joinLote = root.join("lote", JoinType.INNER);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinLoteInfo = joinLote.join("loteInfo", JoinType.INNER);
            Join<LoteMateriaPrimaStatus, PlanoAnalise> joinPA = root.join("planoAnalise", JoinType.INNER);
            cq.multiselect(cb.count(root.get("lote")), 
                    joinPA.get("metodologia").get("id"), 
                    joinPA.get("analise").get("id"),
                    joinPA.get("analiseTipo").get("id"),
                    cb.min(joinLoteInfo.get("dataNecessidade"))
            );
            cq.where(cb.and(cb.notEqual(root.get("analiseStatus"), status), cb.equal(joinPA.get("setor"), lab)));
            cq.groupBy(joinPA.get("metodologia"), 
                    joinPA.get("analise"), 
                    joinPA.get("analiseTipo")
            );
            TypedQuery<Object[]> q = em.createQuery(cq);
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

}
