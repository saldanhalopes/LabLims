package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteMateriaPrimaFaltante;
import br.com.lablims.model.Material;
import javax.persistence.EntityManager;

/**
 *
 * @author rafael
 */
public class LoteMateriaPrimaFaltanteDAO extends GenenicoDAO<LoteMateriaPrimaFaltante> {

    public void salvarLoteMateriaPrimaFaltante(LoteMateriaPrimaFaltante loteFaltante, Material material) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            em.getTransaction().begin();
            material = em.find(Material.class, material.getId());
            loteFaltante.setMaterial(material);
            em.persist(loteFaltante);
            em.getTransaction().commit();
        } catch (Exception ex) {
            em.getTransaction().rollback();
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

}
