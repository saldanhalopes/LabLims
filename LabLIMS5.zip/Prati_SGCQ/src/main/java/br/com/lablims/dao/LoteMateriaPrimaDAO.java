package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteMateriaPrima;
import br.com.lablims.model.LoteMateriaPrimaInfo;
import br.com.lablims.model.Material;
import static com.fasterxml.classmate.types.ResolvedPrimitiveType.all;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

/**
 *
 * @author rafael
 */
public class LoteMateriaPrimaDAO extends GenenicoDAO<LoteMateriaPrima> {

    public Boolean checkLoteMateriaPrimaIsExits(String lote) throws EntityNotFoundException, NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLote", LoteMateriaPrima.class)
                    .setParameter("lote", lote)
                    .getSingleResult().getLote() != null;
        } catch (NoResultException ex) {
            return false;
        } finally {
            em.close();
        }
    }

    public LoteMateriaPrima findLoteMateriaPrimaByLote(String lote) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLote", LoteMateriaPrima.class)
                    .setParameter("lote", lote)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<LoteMateriaPrima> findListLoteMateriaPrima(Integer maxResults, Map<String, String> conditional) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            Join<LoteMateriaPrima, Material> joinMaterial = root.join("material", JoinType.INNER);
            if (conditional != null) {
                for (String key : conditional.keySet()) {
                    cq.where(cb.equal(joinInfo.get(key), conditional.get(key)));
                }
            }
            cq.orderBy(cb.asc(joinMaterial.get("material")));
            cq.select(root);
            Query q = em.createQuery(cq);
            if (maxResults != null) {
                q.setMaxResults(maxResults);
            }
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

}
