/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import br.com.lablims.interfaces.EntidadeBase;
import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

/**
 * <code>LoteMateriaPrima</code> classe LoteMateriaPrima
 *
 * @author rafae.lopes
 * @version 1.00
 */
@Entity
@Table(name = "tb_lote_materia_prima")
@NamedQueries({
    @NamedQuery(name = "LoteMateriaPrima.findLote", query = "Select l FROM LoteMateriaPrima l WHERE l.lote = :lote")})
@DynamicInsert(true)
@DynamicUpdate(true)
public class LoteMateriaPrima implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lote", unique = true, length = 50)
    private String lote;

    @ManyToOne()
    @JoinColumn(name = "material_id", referencedColumnName = "id")
    private Material material;
    
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "lote")
    private LoteMateriaPrimaInfo loteInfo;

    public LoteMateriaPrima() {
    }

    public LoteMateriaPrima(Long id) {
        this.id = id;
    }

    public LoteMateriaPrima(String lote, LoteMateriaPrimaInfo loteInfo) {
        this.lote = lote;
        this.loteInfo = loteInfo;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public LoteMateriaPrimaInfo getLoteInfo() {
        return loteInfo;
    }

    public void setLoteInfo(LoteMateriaPrimaInfo loteInfo) {
        this.loteInfo = loteInfo;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 19 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoteMateriaPrima other = (LoteMateriaPrima) obj;
        return Objects.equals(this.id, other.id);
    }

}
