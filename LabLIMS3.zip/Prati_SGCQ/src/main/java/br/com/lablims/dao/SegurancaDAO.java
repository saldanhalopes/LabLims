package br.com.lablims.dao;

import br.com.lablims.model.Seguranca;

/**
 *
 * @author rafael
 */
public class SegurancaDAO extends GenenicoDAO<Seguranca> {
    
}
