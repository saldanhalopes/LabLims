package br.com.lablims.dao;

import br.com.lablims.model.Form;

/**
 *
 * @author rafael
 */
public class FormDAO extends GenenicoDAO<Form> {
    
}
