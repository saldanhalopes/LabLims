package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteMateriaPrima;
import br.com.lablims.model.LoteMateriaPrimaInfo;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import org.apache.commons.lang3.time.DateUtils;

/**
 *
 * @author rafael
 */
public class LoteMateriaPrimaDAO extends GenenicoDAO<LoteMateriaPrima> {

    public Boolean checkLoteMateriaPrimaIsExits(String lote) throws EntityNotFoundException, NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLote", LoteMateriaPrima.class)
                    .setParameter("lote", lote)
                    .getSingleResult().getLote() != null;
        } catch (NoResultException ex) {
            return false;
        } finally {
            em.close();
        }
    }

    public LoteMateriaPrima findLoteMateriaPrimaByLote(String lote) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLote", LoteMateriaPrima.class)
                    .setParameter("lote", lote)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public LoteMateriaPrima findLoteMateriaPrimaPlanoAnalise(Long lote_id) throws NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrima.findLoteMateriaPrimaPlanoAnalise", LoteMateriaPrima.class)
                    .setParameter("id", lote_id)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<LoteMateriaPrima> findListLoteMateriaPrima(Integer maxResults,
            Map<String, String> conditional) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            if (conditional != null) {
                for (String key : conditional.keySet()) {
                    if ("Todos".equals(conditional.get(key))) {
                        cq.where(cb.notEqual(joinInfo.get(key), "Liberado"));
                    } else {
                        cq.where(cb.equal(joinInfo.get(key), conditional.get(key)));
                    }
                }
            }
            cq.orderBy(cb.desc(root.get("id")));
            cq.select(root);
            Query q = em.createQuery(cq);
            if (maxResults != null) {
                q.setMaxResults(maxResults);
            }
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

    public List<Object[]> findLoteStatus(Integer maxResults)throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            String sql = "SELECT CAST (tb_lote_materia_prima.id AS INTEGER), tb_lote_materia_prima.lote, "
                    + "tb_lote_materia_prima_info.data_necessidade, tb_lote_materia_prima_info.prev_liberacao, "
                    + "tb_lote_materia_prima_info.obs_cq, tb_material.cod_material, tb_material.material, "
                    + "(Select COUNT(tb_lote_materia_prima_status.id) FROM tb_lote_materia_prima_status "
                    + "WHERE tb_lote_materia_prima_status.lote_id = tb_lote_materia_prima.id) as count_analise, "
                    + "(Select COUNT(tb_lote_materia_prima_status.id) FROM tb_lote_materia_prima_status "
                    + "WHERE tb_lote_materia_prima_status.lote_id = tb_lote_materia_prima.id "
                    + "AND tb_lote_materia_prima_status.status_id = 4) as count_analise_finalizada "
                    + "FROM tb_lote_materia_prima "
                    + "INNER JOIN tb_lote_materia_prima_info "
                    + "ON tb_lote_materia_prima.id = tb_lote_materia_prima_info.id "
                    + "LEFT JOIN tb_material "
                    + "ON tb_lote_materia_prima.material_id = tb_material.id "
                    + "WHERE tb_lote_materia_prima_info.status <> 'Liberado' "
                    + "ORDER BY tb_lote_materia_prima.id DESC "
                    + "limit :limit";
            Query query = em.createNativeQuery(sql);
            query.setParameter("limit", maxResults);
            return query.getResultList();
        } catch (Exception e) {
            return null;
        } finally {
            em.close();
        }
    }
    
    public List<Object[]> findLoteStatus(Integer maxResults, Long pa_id) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            String sql = "SELECT CAST (tb_lote_materia_prima.id AS INTEGER), tb_lote_materia_prima.lote, "
                    + "tb_lote_materia_prima_info.data_necessidade, tb_lote_materia_prima_info.prev_liberacao, "
                    + "tb_lote_materia_prima_info.obs_cq, tb_material.cod_material, tb_material.material, "
                    + "(Select COUNT(tb_lote_materia_prima_status.id) FROM tb_lote_materia_prima_status "
                    + "WHERE tb_lote_materia_prima_status.lote_id = tb_lote_materia_prima.id) as count_analise, "
                    + "(Select COUNT(tb_lote_materia_prima_status.id) FROM tb_lote_materia_prima_status "
                    + "WHERE tb_lote_materia_prima_status.lote_id = tb_lote_materia_prima.id "
                    + "AND tb_lote_materia_prima_status.status_id = 4) as count_analise_finalizada "
                    + "FROM tb_lote_materia_prima "
                    + "INNER JOIN tb_lote_materia_prima_info "
                    + "ON tb_lote_materia_prima.id = tb_lote_materia_prima_info.id "
                    + "LEFT JOIN tb_material "
                    + "ON tb_lote_materia_prima.material_id = tb_material.id "
                    + "WHERE tb_lote_materia_prima_info.status <> 'Liberado' "
                    + "AND tb_lote_materia_prima.id IN "
                    + "(SELECT tb_lote_materia_prima_status.lote_id "
                    + "FROM tb_lote_materia_prima_status "
                    + "WHERE tb_lote_materia_prima_status.plano_analise_id = :pa_id "
                    + "AND tb_lote_materia_prima_status.status_id <> 4) "
                    + "ORDER BY tb_lote_materia_prima.id DESC "
                    + "limit :limit";
            Query query = em.createNativeQuery(sql);
            query.setParameter("limit", maxResults);
            query.setParameter("pa_id", pa_id);
            return query.getResultList();
        } catch (Exception e) {
            return null;
        } finally {
            em.close();
        }
    }

    public Integer getCountLotes() throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            cq.where(cb.notEqual(joinInfo.get("status"), "Liberado"));
            cq.select(cb.count(root));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

    public Integer getCountLotesVermelhos() throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            cq.where(cb.and(
                    cb.notEqual(joinInfo.get("status"), "Liberado"),
                    cb.lessThanOrEqualTo(joinInfo.get("dataNecessidade"), new Date())
            ));
            cq.select(cb.count(root));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }
    
    public Integer getCountLotesLiberados() throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            Date date = DateUtils.addDays(new Date(), -1);
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<LoteMateriaPrima> root = cq.from(LoteMateriaPrima.class);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinInfo = root.join("loteInfo", JoinType.INNER);
            cq.where(cb.and(
                    cb.equal(joinInfo.get("status"), "Liberado"),
                    cb.greaterThanOrEqualTo(joinInfo.get("dataStatus"), date)
            ));
            cq.select(cb.count(root));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

}
