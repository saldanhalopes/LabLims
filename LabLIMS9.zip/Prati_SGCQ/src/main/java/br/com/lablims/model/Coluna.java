/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import br.com.lablims.audit.Audit;
import br.com.lablims.audit.AuditListener;
import br.com.lablims.interfaces.EntidadeBase;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

 /**
 * O <code>Usuario</code> classe Usuario
 *
 * @author rafae.lopes
 * @version 1.00
 */
@Entity
@Table(name = "tb_coluna")
@DynamicInsert(true)
@DynamicUpdate(true)
@Audited(withModifiedFlag = true)
@AuditTable(value = "tba_coluna_auditoria")
@EntityListeners(AuditListener.class)
public class Coluna implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "codigo_sap")
    private String codigoSap;
    
    @ManyToOne()
    @JoinColumn(name = "setor_id", referencedColumnName = "id")
    private Setor setor;
    
    @ManyToOne()
    @JoinColumn(name = "metodologia_id", referencedColumnName = "id")
    private Metodologia metodologia;
    
    @ManyToOne()
    @JoinColumn(name = "analise_id", referencedColumnName = "id")
    private Analise analise;
    
    @Column(name = "analise_obs")
    private String analiseObs;
    
    @ManyToOne()
    @JoinColumn(name = "tipo_coluna", referencedColumnName = "id")
    private ColunaConfig tipoColuna;
    
    @ManyToOne()
    @JoinColumn(name = "fabricante_coluna", referencedColumnName = "id")
    private ColunaConfig fabricanteColuna;
    
    @ManyToOne()
    @JoinColumn(name = "marca_coluna", referencedColumnName = "id")
    private ColunaConfig marcaColuna;
    
    @ManyToOne()
    @JoinColumn(name = "fase_coluna", referencedColumnName = "id")
    private ColunaConfig faseColuna;
    
    @ManyToOne()
    @JoinColumn(name = "tamanho_coluna", referencedColumnName = "id")
    private ColunaConfig tamanhoColuna;
    
    @ManyToOne()
    @JoinColumn(name = "diametro_coluna", referencedColumnName = "id")
    private ColunaConfig diametroColuna;
    
    @ManyToOne()
    @JoinColumn(name = "particula_coluna", referencedColumnName = "id")
    private ColunaConfig particulaColuna;
    
    @ManyToOne()
    @JoinColumn(name = "part_number", referencedColumnName = "id")
    private ColunaConfig partNumber;
    
    @Column(name = "serial_number")
    private String serialNumber;
    
    @Column(name = "data_ativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAtivacao;
    
    @ManyToOne()
    @JoinColumn(name = "user_ativacao", referencedColumnName = "id")
    private Usuario userAtivacao;
    
    @Column(name = "data_descarte")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataDescarte;
    
    @ManyToOne()
    @JoinColumn(name = "user_descarte", referencedColumnName = "id")
    private Usuario userDescarte;
    
    @Column(name = "data_performance")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataPerformance;
    
    @ManyToOne()
    @JoinColumn(name = "user_performance", referencedColumnName = "id")
    private Usuario userPerformance;
    
    @Column(name = "data_verificacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataVerificacao;
    
    @ManyToOne()
    @JoinColumn(name = "user_verificacao", referencedColumnName = "id")
    private Usuario userVerificacao;
    
    @ManyToOne()
    @JoinColumn(name = "vaga_id", referencedColumnName = "id")
    private ColunaVaga vaga;
    
    @Column(name = "obs")
    private String obs;

    @Transient
    private Audit audit = new Audit();

    @Transient
    private Boolean CodigoSap_MOD;
    
    @Transient
    private Boolean Setor_MOD;
    
    @Transient
    private Boolean Metodologia_MOD;
    
    @Transient
    private Boolean Analise_MOD;
    
    @Transient
    private Boolean AnaliseObs_MOD;
    
    @Transient
    private Boolean TipoColuna_MOD;
    
    @Transient
    private Boolean FabricanteColuna_MOD;
    
    @Transient
    private Boolean MarcaColuna_MOD;
    
    @Transient
    private Boolean FaseColuna_MOD;
    
    @Transient
    private Boolean TamanhoColuna_MOD;
    
    @Transient
    private Boolean DiametroColuna_MOD;
    
    @Transient
    private Boolean particulaColuna_MOD;
    
    @Transient
    private Boolean PartNumber_MOD;
    
    @Transient
    private Boolean SerialNumber_MOD;
    
    @Transient
    private Boolean DataAtivacao_MOD;
    
    @Transient
    private Boolean UserAtivacao_MOD;
    
    @Transient
    private Boolean DataDescarte_MOD;
    
    @Transient
    private Boolean UserDescarte_MOD;
    
    @Transient
    private Boolean DataPerformance_MOD;
    
    @Transient
    private Boolean UserPerformance_MOD;
    
    @Transient
    private Boolean DataVerificacao_MOD;
    
    @Transient
    private Boolean UserVerificacao_MOD;
    
    @Transient
    private Boolean Vaga_MOD;
    
    @Transient
    private Boolean Obs_MOD;
        
    public Coluna() {
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoSap() {
        return codigoSap;
    }

    public void setCodigoSap(String codigoSap) {
        this.codigoSap = codigoSap;
    }

    public Setor getSetor() {
        return setor;
    }

    public void setSetor(Setor setor) {
        this.setor = setor;
    }

    public Metodologia getMetodologia() {
        return metodologia;
    }

    public void setMetodologia(Metodologia metodologia) {
        this.metodologia = metodologia;
    }

    public Analise getAnalise() {
        return analise;
    }

    public void setAnalise(Analise analise) {
        this.analise = analise;
    }

    public String getAnaliseObs() {
        return analiseObs;
    }

    public void setAnaliseObs(String analiseObs) {
        this.analiseObs = analiseObs;
    }

    public ColunaConfig getTipoColuna() {
        return tipoColuna;
    }

    public void setTipoColuna(ColunaConfig tipoColuna) {
        this.tipoColuna = tipoColuna;
    }

    public ColunaConfig getFabricanteColuna() {
        return fabricanteColuna;
    }

    public void setFabricanteColuna(ColunaConfig fabricanteColuna) {
        this.fabricanteColuna = fabricanteColuna;
    }

    public ColunaConfig getMarcaColuna() {
        return marcaColuna;
    }

    public void setMarcaColuna(ColunaConfig marcaColuna) {
        this.marcaColuna = marcaColuna;
    }

    public ColunaConfig getFaseColuna() {
        return faseColuna;
    }

    public void setFaseColuna(ColunaConfig faseColuna) {
        this.faseColuna = faseColuna;
    }

    public ColunaConfig getTamanhoColuna() {
        return tamanhoColuna;
    }

    public void setTamanhoColuna(ColunaConfig tamanhoColuna) {
        this.tamanhoColuna = tamanhoColuna;
    }

    public ColunaConfig getDiametroColuna() {
        return diametroColuna;
    }

    public void setDiametroColuna(ColunaConfig diametroColuna) {
        this.diametroColuna = diametroColuna;
    }

    public ColunaConfig getParticulaColuna() {
        return particulaColuna;
    }

    public void setParticulaColuna(ColunaConfig particulaColuna) {
        this.particulaColuna = particulaColuna;
    }

    public ColunaConfig getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(ColunaConfig partNumber) {
        this.partNumber = partNumber;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public Date getDataAtivacao() {
        return dataAtivacao;
    }

    public void setDataAtivacao(Date dataAtivacao) {
        this.dataAtivacao = dataAtivacao;
    }

    public Usuario getUserAtivacao() {
        return userAtivacao;
    }

    public void setUserAtivacao(Usuario userAtivacao) {
        this.userAtivacao = userAtivacao;
    }

    public Date getDataDescarte() {
        return dataDescarte;
    }

    public void setDataDescarte(Date dataDescarte) {
        this.dataDescarte = dataDescarte;
    }

    public Usuario getUserDescarte() {
        return userDescarte;
    }

    public void setUserDescarte(Usuario userDescarte) {
        this.userDescarte = userDescarte;
    }

    public Date getDataPerformance() {
        return dataPerformance;
    }

    public void setDataPerformance(Date dataPerformance) {
        this.dataPerformance = dataPerformance;
    }

    public Usuario getUserPerformance() {
        return userPerformance;
    }

    public void setUserPerformance(Usuario userPerformance) {
        this.userPerformance = userPerformance;
    }

    public Date getDataVerificacao() {
        return dataVerificacao;
    }

    public void setDataVerificacao(Date dataVerificacao) {
        this.dataVerificacao = dataVerificacao;
    }

    public Usuario getUserVerificacao() {
        return userVerificacao;
    }

    public void setUserVerificacao(Usuario userVerificacao) {
        this.userVerificacao = userVerificacao;
    }

    public ColunaVaga getVaga() {
        return vaga;
    }

    public void setVaga(ColunaVaga vaga) {
        this.vaga = vaga;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Coluna other = (Coluna) obj;
        return Objects.equals(this.id, other.id);
    }

}
