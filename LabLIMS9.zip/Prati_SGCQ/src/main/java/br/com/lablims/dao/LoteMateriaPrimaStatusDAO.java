package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteMateriaPrima;
import br.com.lablims.model.LoteMateriaPrimaInfo;
import br.com.lablims.model.LoteMateriaPrimaStatus;
import br.com.lablims.model.PlanoAnalise;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

/**
 *
 * @author rafael
 */
public class LoteMateriaPrimaStatusDAO extends GenenicoDAO<LoteMateriaPrimaStatus> {

    public LoteMateriaPrimaStatus findStatusByPlanoAnalise(Long lote_id, Long pa_id) throws EntityNotFoundException, NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrimaStatus.findStatusByPlanoAnalise", LoteMateriaPrimaStatus.class)
                    .setParameter("lote_id", lote_id)
                    .setParameter("pa_id", pa_id)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<LoteMateriaPrimaStatus> findLotesByStatus(Long lote_id) throws EntityNotFoundException, NoResultException {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("LoteMateriaPrimaStatus.findStatus", LoteMateriaPrimaStatus.class)
                    .setParameter("lote_id", lote_id)
                    .getResultList();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<Object[]> findLoteStatusByMetodologia(Long status, Long lab) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<LoteMateriaPrimaStatus> root = cq.from(LoteMateriaPrimaStatus.class);
            Join<LoteMateriaPrimaStatus, LoteMateriaPrima> joinLote = root.join("lote", JoinType.INNER);
            Join<LoteMateriaPrima, LoteMateriaPrimaInfo> joinLoteInfo = joinLote.join("loteInfo", JoinType.INNER);
            Join<LoteMateriaPrimaStatus, PlanoAnalise> joinPA = root.join("planoAnalise", JoinType.INNER);
            cq.multiselect(cb.count(root.get("lote")),
                    joinPA.get("metodologia").get("id"),
                    joinPA.get("analise").get("id"),
                    joinPA.get("analiseTipo").get("id"),
                    cb.min(joinLoteInfo.get("dataNecessidade")),
                    root.get("planoAnalise").get("id")
            );
            cq.where(
                    cb.and(
                            cb.notEqual(root.get("analiseStatus"), status),
                            cb.equal(joinPA.get("setor"), lab),
                            cb.notEqual(joinLoteInfo.get("status"), "Liberado")
                    )
            );
            cq.groupBy(joinPA.get("metodologia"),
                    joinPA.get("analise"),
                    joinPA.get("analiseTipo"),
                    root.get("planoAnalise")
            );
            TypedQuery<Object[]> q = em.createQuery(cq);
            return q.getResultList();
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

}
