package br.com.lablims.dao;

import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.TransactionRequiredException;
import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.Login;
import br.com.lablims.model.Usuario;

/**
 *
 * @author rafael
 */
public class LoginDAO extends GenenicoDAO<Login> {

    public void loginUsuario(Usuario user) throws TransactionRequiredException {
        EntityManager em = ConnectionFactory.em();
        Login login = new Login();
        try {
            em.getTransaction().begin();
            login.setUsuario(user);
            login.setLastlogin(new Date());
            em.persist(login);
            em.getTransaction().commit();
        } catch (TransactionRequiredException ex) {
            em.getTransaction().rollback();
            throw new TransactionRequiredException("Erro ao Atualizar!");
        }finally{
            em.close();
        }
    }

    public void logoffUsuario(Usuario user) throws TransactionRequiredException {
        EntityManager em = ConnectionFactory.em();
        Login login = new Login();
        try {
            em.getTransaction().begin();
            login.setUsuario(user);
            login.setLastlogout(new Date());
            em.persist(login);
            em.getTransaction().commit();
        } catch (TransactionRequiredException ex) {
            em.getTransaction().rollback();
            throw new TransactionRequiredException("Erro ao Atualizar!");
        }finally{
            em.close();
        }
    }

}
