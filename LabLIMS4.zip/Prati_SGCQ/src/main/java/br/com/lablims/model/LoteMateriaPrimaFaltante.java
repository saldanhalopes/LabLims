/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import br.com.lablims.interfaces.EntidadeBase;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author rafael.lopes
 */
@Entity
@Table(name = "tb_lote_materia_prima_faltante")
public class LoteMateriaPrimaFaltante implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private Integer id;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "id")
    private Material material;

    @Column(name = "data_necessidade")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataNecessidade;

    @Column(name = "qtd_necessaria", precision = 16, scale = 6)
    private BigDecimal qtdNecessaria;

    @Column(name = "status")
    private String status;

    @Column(name = "obs_cq")
    private String obsCq;

    public LoteMateriaPrimaFaltante() {
    }

    public LoteMateriaPrimaFaltante(Integer id) {
        this.id = id;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Date getDataNecessidade() {
        return dataNecessidade;
    }

    public void setDataNecessidade(Date dataNecessidade) {
        this.dataNecessidade = dataNecessidade;
    }

    public BigDecimal getQtdNecessaria() {
        return qtdNecessaria;
    }

    public void setQtdNecessaria(BigDecimal qtdNecessaria) {
        this.qtdNecessaria = qtdNecessaria;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getObsCq() {
        return obsCq;
    }

    public void setObsCq(String obsCq) {
        this.obsCq = obsCq;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoteMateriaPrimaFaltante other = (LoteMateriaPrimaFaltante) obj;
        return Objects.equals(this.id, other.id);
    }

}
