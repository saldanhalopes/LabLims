package br.com.lablims.dao;

import br.com.lablims.model.FalhaAcesso;

/**
 *
 * @author rafael
 */
public class FalhaAcessoDAO extends GenenicoDAO<FalhaAcesso> {

}
