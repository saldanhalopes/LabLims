/*
 * Copyright (C) 2019 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.Material;
import javax.persistence.EntityManager;

/**
 *
 * @author rafael.lopes
 */
public class MaterialDAO extends GenenicoDAO<Material> {
    
    
    public Material findMaterialByCodMaterial(Integer material_id) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            return em.createNamedQuery("Material.findByMaterial", Material.class)
                    .setParameter("codMaterial", material_id)
                    .getSingleResult();
        } catch (Exception ex) {
            return null;
        } finally {
            em.close();
        }
    }
    
    
    

//    public List<Material> readMaterialAuditoria() {
//        Connection conn = ConnectionFactory.getConnection();
//        PreparedStatement stmt = null;
//        ResultSet rs = null;
//        List<Material> materiais = new ArrayList<>();
//        try {
//            stmt = conn.prepareStatement("SELECT tba_metodologia_auditoria.*, "
//                    + "tba_audit_revinfo.computador, "
//                    + "tba_audit_revinfo.ultima_modificacao, "
//                    + "tba_audit_revinfo.user_computador, "
//                    + "tba_audit_revinfo.modificado_por, "
//                    + "tba_audit_revinfo.motivo "
//                    + "FROM tba_metodologia_auditoria  "
//                    + "INNER JOIN tba_audit_revinfo "
//                    + "ON tba_metodologia_auditoria.REV = tba_audit_revinfo.id "
//                    + "ORDER BY tba_metodologia_auditoria.REV DESC ");
//            rs = stmt.executeQuery();
//            while (rs.next()) {
//                Material mtd = new Material();
//                Audit audit = new Audit();
//                mtd.setId(rs.getInt("id"));
//                mtd.setCodMetodo(rs.getString("cod_metodo"));
//                mtd.setMetodo(rs.getString("metodo"));
//                mtd.setCategoria(rs.getString("categoria"));
//                mtd.setLink(rs.getString("link"));
//                mtd.setVersao(rs.getInt("versao"));
//                mtd.setCodMetodo_MOD(rs.getInt("codMetodo_MOD"));
//                mtd.setMetodo_MOD(rs.getInt("metodo_MOD"));
//                mtd.setCategoria_MOD(rs.getInt("categoria_MOD"));
//                mtd.setLink_MOD(rs.getInt("link_MOD"));
//                mtd.setVersao_MOD(rs.getInt("versao_MOD"));
//                mtd.setVersion(rs.getInt("version"));
//                mtd.setMOD(rs.getInt("REVTYPE"));
//                audit.setComputador(rs.getString("computador"));
//                audit.setUserComputador(rs.getString("user_computador"));
//                audit.setUltimaModificacao(rs.getTimestamp("ultima_modificacao"));
//                audit.setUltimaModificacaoPor(rs.getString("modificado_por"));
//                audit.setMotivo(rs.getString("motivo"));
//                mtd.setAudit(audit);
//                materiais.add(mtd);
//            }
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null, "Erro: " + ex);
//        } finally {
//            ConnectionFactory.closeConection(conn, stmt, rs);
//        }
//        return materiais;
//    }

}
