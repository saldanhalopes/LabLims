/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import br.com.lablims.audit.Audit;
import br.com.lablims.audit.AuditListener;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import br.com.lablims.interfaces.EntidadeBase;
import java.math.BigDecimal;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

/**
 *
 * @author rafael.lopes
 */
@Entity
@Table(name = "tb_lote_produto_acabado_devedor")
@NamedQueries({
    @NamedQuery(name = "LoteProdutoAcabadoDevedor.findAll", query = "SELECT lm FROM LoteProdutoAcabadoDevedor lm INNER JOIN lm.material mat"),
    @NamedQuery(name = "LoteProdutoAcabadoDevedor.findDevedor", query = "SELECT ld FROM LoteProdutoAcabadoDevedor ld INNER JOIN ld.material mat WHERE ld.qtdDevedora IS NOT NULL")})
@DynamicInsert(true)
@DynamicUpdate(true)
@Audited(withModifiedFlag = true)
@AuditTable(value = "tba_lote_produto_acabado_devedor_auditoria")
@EntityListeners(AuditListener.class)
public class LoteProdutoAcabadoDevedor implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @MapsId
    @JoinColumn(name = "id")
    private Material material;

    @Column(name = "qtd_devedora", precision = 16, scale = 6)
    private BigDecimal qtdDevedora;
    
    @Column(name = "qtd_estoque", precision = 16, scale = 6)
    private BigDecimal qtdEstoque;

    @Column(name = "version")
    private Integer version;
    
    @Transient
    private Audit audit = new Audit();

    @Transient
    private Boolean QtdEstoque_MOD;

    @Transient
    private Boolean QtdDevedora_MOD;

    public LoteProdutoAcabadoDevedor() {
    }

    public LoteProdutoAcabadoDevedor(Long id) {
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

       public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public BigDecimal getQtdDevedora() {
        return qtdDevedora;
    }

    public void setQtdDevedora(BigDecimal qtdDevedora) {
        this.qtdDevedora = qtdDevedora;
    }

    public BigDecimal getQtdEstoque() {
        return qtdEstoque;
    }

    public void setQtdEstoque(BigDecimal qtdEstoque) {
        this.qtdEstoque = qtdEstoque;
    }

    public Boolean getQtdEstoque_MOD() {
        return QtdEstoque_MOD;
    }

    public void setQtdEstoque_MOD(Boolean QtdEstoque_MOD) {
        this.QtdEstoque_MOD = QtdEstoque_MOD;
    }

    public Boolean getQtdDevedora_MOD() {
        return QtdDevedora_MOD;
    }

    public void setQtdDevedora_MOD(Boolean QtdDevedora_MOD) {
        this.QtdDevedora_MOD = QtdDevedora_MOD;
    }
        
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoteProdutoAcabadoDevedor other = (LoteProdutoAcabadoDevedor) obj;
        return Objects.equals(this.id, other.id);
    }

}
