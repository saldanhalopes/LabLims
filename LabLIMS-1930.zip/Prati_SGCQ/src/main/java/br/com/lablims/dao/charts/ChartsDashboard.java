/*
 * Copyright (C) 2019 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.dao.charts;

import br.com.lablims.dao.LoteMateriaPrimaDAO;
import br.com.lablims.dao.LoteMateriaPrimaInfoDAO;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

/**
 *
 * @author rafael.lopes
 */
public class ChartsDashboard {

    public static CategoryDataset datasetLotesLiberados(Integer dias) throws Exception {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        LoteMateriaPrimaDAO loteDAO = new LoteMateriaPrimaDAO();
        try {
            for (Object[] objects : loteDAO.getLotesLiberados(dias)) {
                dataset.addValue((Number) objects[0], "MP", objects[1].toString() + "/" + objects[2].toString());
            }
        } catch (Exception ex) {
            throw new Exception(ex);
        }
        return dataset;
    }

    public static CategoryDataset mediaLotesLiberados(Integer dias) throws Exception {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        LoteMateriaPrimaDAO loteDAO = new LoteMateriaPrimaDAO();
        List<Object[]> values = loteDAO.getLotesLiberados(dias);
        Long total = 0L;
        try {
            for (Object[] objects : values) {
                total = ((Long) objects[0]) + total;
            }
            for (Object[] objects : values) {
                dataset.addValue(total / dias, "Média", objects[1].toString() + "/" + objects[2].toString());
            }
        } catch (Exception ex) {
            throw new Exception(ex);
        }
        return dataset;
    }

    public static CategoryDataset datasetLotesEntrada(Integer dias) throws Exception {
        final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        LoteMateriaPrimaInfoDAO loteInfoDAO = new LoteMateriaPrimaInfoDAO();
        try {
            for (Object[] objects : loteInfoDAO.getLotesStatusEntrada(dias)) {
                dataset.addValue((Number) objects[0], "Entrada MP", objects[1].toString() + "/" + objects[2].toString());
            }
        } catch (Exception ex) {
            throw new Exception(ex);
        }
        return dataset;
    }
    
    public static CategoryDataset mediaLotesEntrada(Integer dias) throws Exception {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        LoteMateriaPrimaInfoDAO loteInfoDAO = new LoteMateriaPrimaInfoDAO();
        List<Object[]> values = loteInfoDAO.getLotesStatusEntrada(dias);
        Long total = 0L;
        try {
            for (Object[] objects : values) {
                total = ((Long) objects[0]) + total;
            }
            for (Object[] objects : values) {
                dataset.addValue(total / dias, "Média", objects[1].toString() + "/" + objects[2].toString());
            }
        } catch (Exception ex) {
            throw new Exception(ex);
        }
        return dataset;
    }

    public static PieDataset datasetStatusData(Date inicio, Date fim) throws Exception {
        DefaultPieDataset dataset = new DefaultPieDataset();
        LoteMateriaPrimaInfoDAO loteInfoDAO = new LoteMateriaPrimaInfoDAO();
        try {
            dataset.setValue("Entrada", loteInfoDAO.getCountStatusEntradaLotes(inicio, fim));
            dataset.setValue("Amostragem", loteInfoDAO.getCountStatusAmostragemLotes(inicio, fim));
            dataset.setValue("Em CQ", loteInfoDAO.getCountStatusEmCqLotes(inicio, fim));
            dataset.setValue("Documental", loteInfoDAO.getCountStatusDocumentalLotes(inicio, fim));
            dataset.setValue("Liberados", loteInfoDAO.getCountStatusLiberadoLotes(inicio, fim));
        } catch (Exception ex) {
            throw new Exception(ex);
        }
        return dataset;
    }
}
