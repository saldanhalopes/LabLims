package br.com.lablims.dao;

import br.com.lablims.connection.ConnectionFactory;
import br.com.lablims.model.LoteProdutoAcabadoDevedor;
import br.com.lablims.model.Material;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author rafael
 */
public class LoteProdutoAcabadoDevedorDAO extends GenenicoDAO<LoteProdutoAcabadoDevedor> {

    public List<LoteProdutoAcabadoDevedor> findAll() throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            Query q = em.createNamedQuery("LoteProdutoAcabadoDevedor.findAll", LoteProdutoAcabadoDevedor.class);
            return q.getResultList();
        } catch (Exception ex) {
            return null;
        } finally {
            em.close();
        }
    }
    
    public List<LoteProdutoAcabadoDevedor> findFantantes() throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            Query q = em.createNamedQuery("LoteProdutoAcabadoDevedor.findFaltantes", LoteProdutoAcabadoDevedor.class);
            return q.getResultList();
        } catch (Exception ex) {
            return null;
        } finally {
            em.close();
        }
    }
    
    public void salvarLoteProdutoAcabadoDevedor(LoteProdutoAcabadoDevedor loteFaltante, Material material) throws Exception {
        EntityManager em = ConnectionFactory.em();
        try {
            em.getTransaction().begin();
            material = em.find(Material.class, material.getId());
            loteFaltante.setMaterial(material);
            em.persist(loteFaltante);
            em.getTransaction().commit();
        } catch (Exception ex) {
            em.getTransaction().rollback();
            throw new Exception(ex);
        } finally {
            em.close();
        }
    }

}
