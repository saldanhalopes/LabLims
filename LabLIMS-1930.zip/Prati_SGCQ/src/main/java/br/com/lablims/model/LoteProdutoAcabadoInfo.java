/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package br.com.lablims.model;

import br.com.lablims.audit.Audit;
import br.com.lablims.audit.AuditListener;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import br.com.lablims.interfaces.EntidadeBase;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

/**
 *
 * @author rafael.lopes
 */
@Entity
@Table(name = "tb_lote_produto_acabado_info")
@DynamicInsert(true)
@DynamicUpdate(true)
@Audited(withModifiedFlag = true)
@AuditTable(value = "tba_lote_produto_acabado_info_auditoria")
@EntityListeners(AuditListener.class)
public class LoteProdutoAcabadoInfo implements EntidadeBase, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private Long id;

    @NotAudited
    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "id")
    private LoteProdutoAcabado lotePa;

    @Column(name = "data_entrada")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEntrada;
    
    @Column(name = "qtd_estoque", precision = 16, scale = 6)
    private BigDecimal qtdEstoque;
    
    @Column(name = "status")
    private String status;

    @Column(name = "data_status")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataStatus;
    
    @Column(name = "prev_liberacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prevLiberacao;
    
    @Column(name = "tempo_estimado_liberacao")
    private String tempoEstimadoLiberacao;
    
    @Column(name = "tempo_real_liberacao")
    private String tempoRealLiberacao;
    
    @Column(name = "obs_cq")
    private String obsCq;
    
    @Column(name = "created", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date created;

    @Column(name = "data_liberado")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataLiberado;
    
    @Column(name = "data_doc")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataDoc;
    
    @Column(name = "version")
    private Integer version;
    
    @Transient
    private Audit audit = new Audit();

    @Transient
    private Boolean QtdEstoque_MOD;
    
    @Transient
    private Boolean Status_MOD;
    
    @Transient
    private Boolean TempoEstimadoLiberacao_MOD;

    @Transient
    private Boolean TempoRealLiberacao_MOD;
    
    @Transient
    private Boolean ObsCq_MOD;

    @Transient
    private Boolean DataEntrada_MOD;
    
    @Transient
    private Boolean DataLiberado_MOD;
    
    @Transient
    private Boolean DataDoc_MOD;
    
     @Transient
    private Boolean DataStatus_MOD;
     
     @Transient
    private Boolean PrevLiberacao_MOD;
    
    public LoteProdutoAcabadoInfo() {
    }

    public LoteProdutoAcabadoInfo(Long id) {
        this.id = id;
    }
    
    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LoteProdutoAcabado getLotePa() {
        return lotePa;
    }

    public void setLotePa(LoteProdutoAcabado lotePa) {
        this.lotePa = lotePa;
    }

    public Date getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(Date dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public BigDecimal getQtdEstoque() {
        return qtdEstoque;
    }

    public void setQtdEstoque(BigDecimal qtdEstoque) {
        this.qtdEstoque = qtdEstoque;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTempoEstimadoLiberacao() {
        return tempoEstimadoLiberacao;
    }

    public void setTempoEstimadoLiberacao(String tempoEstimadoLiberacao) {
        this.tempoEstimadoLiberacao = tempoEstimadoLiberacao;
    }

    public String getTempoRealLiberacao() {
        return tempoRealLiberacao;
    }

    public void setTempoRealLiberacao(String tempoRealLiberacao) {
        this.tempoRealLiberacao = tempoRealLiberacao;
    }

    public String getObsCq() {
        return obsCq;
    }

    public void setObsCq(String obsCq) {
        this.obsCq = obsCq;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getDataLiberado() {
        return dataLiberado;
    }

    public void setDataLiberado(Date dataLiberado) {
        this.dataLiberado = dataLiberado;
    }

    public Date getDataDoc() {
        return dataDoc;
    }

    public void setDataDoc(Date dataDoc) {
        this.dataDoc = dataDoc;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    public Boolean getQtdEstoque_MOD() {
        return QtdEstoque_MOD;
    }

    public void setQtdEstoque_MOD(Boolean QtdEstoque_MOD) {
        this.QtdEstoque_MOD = QtdEstoque_MOD;
    }

    public Boolean getStatus_MOD() {
        return Status_MOD;
    }

    public void setStatus_MOD(Boolean Status_MOD) {
        this.Status_MOD = Status_MOD;
    }

    public Boolean getTempoEstimadoLiberacao_MOD() {
        return TempoEstimadoLiberacao_MOD;
    }

    public void setTempoEstimadoLiberacao_MOD(Boolean TempoEstimadoLiberacao_MOD) {
        this.TempoEstimadoLiberacao_MOD = TempoEstimadoLiberacao_MOD;
    }

    public Boolean getTempoRealLiberacao_MOD() {
        return TempoRealLiberacao_MOD;
    }

    public void setTempoRealLiberacao_MOD(Boolean TempoRealLiberacao_MOD) {
        this.TempoRealLiberacao_MOD = TempoRealLiberacao_MOD;
    }

    public Boolean getObsCq_MOD() {
        return ObsCq_MOD;
    }

    public void setObsCq_MOD(Boolean ObsCq_MOD) {
        this.ObsCq_MOD = ObsCq_MOD;
    }

    public Boolean getDataEntrada_MOD() {
        return DataEntrada_MOD;
    }

    public void setDataEntrada_MOD(Boolean DataEntrada_MOD) {
        this.DataEntrada_MOD = DataEntrada_MOD;
    }

    public Boolean getDataLiberado_MOD() {
        return DataLiberado_MOD;
    }

    public void setDataLiberado_MOD(Boolean DataLiberado_MOD) {
        this.DataLiberado_MOD = DataLiberado_MOD;
    }

    public Boolean getDataDoc_MOD() {
        return DataDoc_MOD;
    }

    public void setDataDoc_MOD(Boolean DataDoc_MOD) {
        this.DataDoc_MOD = DataDoc_MOD;
    }

    public Date getPrevLiberacao() {
        return prevLiberacao;
    }

    public void setPrevLiberacao(Date prevLiberacao) {
        this.prevLiberacao = prevLiberacao;
    }

    public Boolean getPrevLiberacao_MOD() {
        return PrevLiberacao_MOD;
    }

    public void setPrevLiberacao_MOD(Boolean PrevLiberacao_MOD) {
        this.PrevLiberacao_MOD = PrevLiberacao_MOD;
    }

    public Date getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(Date dataStatus) {
        this.dataStatus = dataStatus;
    }

    public Boolean getDataStatus_MOD() {
        return DataStatus_MOD;
    }

    public void setDataStatus_MOD(Boolean DataStatus_MOD) {
        this.DataStatus_MOD = DataStatus_MOD;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoteProdutoAcabadoInfo other = (LoteProdutoAcabadoInfo) obj;
        return Objects.equals(this.id, other.id);
    }

}
